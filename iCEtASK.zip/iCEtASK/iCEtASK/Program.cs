﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace iCEtASK
{

}
        class Program
        {
            static SpeechSynthesizer voice = new SpeechSynthesizer();

            static void Speak(string text)
            {
                voice.Speak(text);
            }

            static void BankLogo()
            {
                WriteLine(@"

██████╗  █████╗ ███╗   ██╗██╗  ██╗
██╔══██╗██╔══██╗████╗  ██║██║ ██╔╝
██████╔╝███████║██╔██╗ ██║█████╔╝ 
██╔══██╗██╔══██║██║╚██╗██║██╔═██╗ 
██████╔╝██║  ██║██║ ╚████║██║  ██╗
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝

BANK SYSTEM

");
            }

            static void Main()
            {
                BankLogo();

                BankAccount acc1 = new BankAccount("Neo", 1234);
                BankAccount acc2 = new BankAccount("Savings", 4321);

                Write("Enter PIN: ");
                int p = Convert.ToInt32(ReadLine());

                if (!acc1.Login(p))
                {
                    WriteLine("Wrong PIN");
                    Speak("Wrong pin");
                    return;
                }

                Speak("Login successful");

                bool run = true;

                while (run)
                {
                    WriteLine("\n1 Deposit");
                    WriteLine("2 Withdraw");
                    WriteLine("3 Balance");
                    WriteLine("4 Transfer");
                    WriteLine("5 History");
                    WriteLine("6 Exit");

                    Speak("Choose option");

                    try
                    {
                        int choice = Convert.ToInt32(ReadLine());

                        Speak("You selected option " + choice);

                        switch (choice)
                        {
                            case 1:

                                Write("Amount:");
                                Speak("Enter deposit amount");

                                double d =
                                Convert.ToDouble(ReadLine());

                                acc1.Deposit(d);

                                break;

                            case 2:

                                Write("Amount:");
                                Speak("Enter withdraw amount");

                                double w =
                                Convert.ToDouble(ReadLine());

                                acc1.Withdraw(w);

                                break;

                            case 3:

                                acc1.CheckBalance();

                                Speak("Balance displayed");

                                break;

                            case 4:

                                Write("Transfer amount:");

                                double t =
                                Convert.ToDouble(ReadLine());

                                acc1.Transfer(acc2, t);

                                Speak("Transfer completed");

                                break;

                            case 5:

                                acc1.ShowHistory();

                                break;

                            case 6:

                                run = false;

                                Speak("Goodbye");

                                break;
                        }
                    }

                    catch (Exception ex)
                    {
                        WriteLine("Error: " + ex.Message);

                        Speak("Error occurred");
                    }
                }
            }
        }
    
