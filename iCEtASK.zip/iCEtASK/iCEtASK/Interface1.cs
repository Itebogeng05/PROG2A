﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;
using System.Media;
using static System.Console;

namespace iCEtASK
{

}

interface IBankOperations
{
    void Deposit(double amount);
    void Withdraw(double amount);
    void CheckBalance();
}

class BankAccount : IBankOperations
{
    private double balance;
    private int pin;

    public string Name;

    public List<string> history = new List<string>();

    public BankAccount(string name, int userPin)
    {
        Name = name;
        pin = userPin;
        balance = 0;
    }

    public bool Login(int enteredPin)
    {
        return enteredPin == pin;
    }

    public void Deposit(double amount)
    {
        if (amount <= 0)
            throw new Exception("Deposit must be greater than zero");

        balance += amount;

        history.Add("Deposit R" + amount);

        WriteLine("Deposit successful");
    }

    public void Withdraw(double amount)
    {
        if (amount > balance)
            throw new Exception("Insufficient funds");

        balance -= amount;

        history.Add("Withdraw R" + amount);

        WriteLine("Withdrawal successful");
    }

    public void CheckBalance()
    {
        WriteLine("Balance = R" + balance);
    }

    public void Transfer(BankAccount other, double amount)
    {
        if (amount > balance)
            throw new Exception("Insufficient funds");

        balance -= amount;
        other.balance += amount;

        history.Add("Transfer R" + amount + " to " + other.Name);
    }

    public void ShowHistory()
    {
        WriteLine("Transactions:");

        foreach (string t in history)
            WriteLine(t);
    }
}